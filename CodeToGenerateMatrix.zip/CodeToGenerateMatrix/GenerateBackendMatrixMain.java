package GenerateBackendMatrix;

public class GenerateBackendMatrixMain 
{

	public static void main(String[] args) 
	{
		if (args.length != 0 && args.length != 4)
		{
			System.out.println("If inputing parameters for generating backend matrix, make sure to have the following parameters in order:");
			System.out.println("\tNode file name");
			System.out.println("\tLayout file name");
			System.out.println("\tOutput file name");
			System.out.println("\tResolution (integer)");
			return;
		}
		
		String nodeFile = "ExampleNodeHeight.txt";
		String layoutFile = "ExampleNodeLayout.txt";
		
		String outputFile = "ExampleMatrix.txt";
		int resolution = 2048;
		
		if (args.length == 3)
		{
			nodeFile = args[0];
			layoutFile = args[1];
			outputFile = args[2];
			resolution  = Integer.parseInt(args[3]);
		}
		
		GeneTerrainData backendData = new GeneTerrainData(nodeFile, layoutFile, resolution);
		backendData.updateBackendWeight(5, 20);
		backendData.setupAllPixelVal();
		backendData.savePixelValue(outputFile);

	}

}
